<!DOCTYPE HTML>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Voitures</title>
    <style>
        .card {
            margin: 20px auto;
            text-align: center;
            cursor: pointer;
            border: none;
            transition: transform 0.3s ease;
        }
        html, body {
            overflow-x: hidden;
        }
        .card-body {
            padding: 0 1.5rem;
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            background: rgba(0, 0, 0, 0.49);
            height: 30%;
            color: white;
        }
        .card:hover {
            transform: scale(1.05);
        }
        .car-image {
            width: 100%;
            height: 300px;
            object-fit: cover;
        }
        .modal-header {
            text-align: center;
        }
        body {
            background-color:black;
        }
        .modal-body {
            display: flex;
            justify-content: center;
            align-items: center;
        }
        html, body {
    overflow-x: hidden;
}

body.modal-open {
    margin-right: 0 !important;
    padding-right: 0 !important;
}

.container {
    transition: margin-right 0.3s ease;
}
p{
  animation: 2s anim-lineUp ease-out;
}

@keyframes anim-lineUp {
   0% {
       opacity: 0;
       transform: translateY(80%);
   }

   20% {
       opacity: 0;
   }

   50% {
       opacity: 1;
       transform: translateY(0%);
   }

   100% {
       opacity: 1;
       transform: translateY(0%);
   }
}

    </style>
</head>

<body>
    <?php include 'navbar.php'; ?>
    <div class="container mt-5">
    <?php
    include("connexion.php");

    $query = "SELECT * FROM VOITURE ORDER BY marque, modele";
    $result = mysqli_query($bdd, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $currentBrand = '';
        $count = 0;

        while ($row = mysqli_fetch_assoc($result)) {
            $marque = $row['marque'];
            $modele = $row['modele'];
            $image_front = $row['image_front'];
            $image_profile = $row['image_profile'];
            $prix = $row['prix'];
            $mini_description = $row['mini_description'];
            $annee = $row['annee'];
            $vitesse = $row['vitesse'];
            $logo_marque = $row['logo_marque'];
            $modalId = "modal_" . $row['id_voiture'];

            // Si la marque change, on affiche un nouveau titre + logo + démarre une nouvelle ligne
            if ($marque !== $currentBrand) {
                if ($count > 0) echo "</div>"; // Ferme la ligne précédente
                echo "
                <div class='text-center mt-3 pt-5'>
                    <h3 style='
                        font-family: \"Montserrat\", sans-serif;
                        font-weight: 800;
                        color: #800e13; font-style: italic;'>
                        $marque
                    </h3>
                    <img src='$logo_marque' style='width: 150px;' alt='Logo $marque'>
                </div>
                <div class='row justify-content-center'>";
                // Nouvelle ligne pour les cartes
                $currentBrand = $marque;
            }

            echo "
            <div class='col-md-4 mb-4 d-flex justify-content-center'>
                <div class='card' style='width: 25rem;' data-bs-toggle='modal' data-bs-target='#$modalId'>
                    <img src='{$image_front}' class='car-image'>
                    <div class='card-body'>
                        <h5 class='card-title'>{$modele}</h5>
                        <p class='card-text'>À partir de {$prix}</p>
                    </div>
                </div>
            </div>

            <div class='modal fade' id='$modalId' tabindex='-1' aria-labelledby='modalTitle_$modalId' aria-hidden='true'>
                <div class='modal-dialog modal-dialog-centered modal-xl'>
                    <div class='modal-content'>
                        <div class='modal-header bg-secondary d-flex justify-content-center'>
                            <h4 class='modal-title text-black'>$marque $modele</h4>
                            <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
                        </div>
                        <div class='modal-body d-flex flex-column flex-md-row justify-content-center align-items-center text-center gap-3'>

                            <img src='{$image_profile}' class='img-fluid' style='max-width: 100%; width: 100%; height: auto; max-width: 500px;'>

                            <div class='d-flex flex-column align-items-center justify-content-center text-black mt-3 mt-md-0'>
                                <p><b>Année :</b> {$annee}</p>
                                <p>{$mini_description}</p>
                                <p><img src='images/logo_prix.png' style='width: 45px;'> {$prix}</p>
                                <p><img src='images/logo_vitesse.png' style='width: 45px;'> {$vitesse}</p>
                            </div>

                        </div>
                    </div>
                </div>
            </div>";
            

            $count++;
        }

        echo "</div>"; // Ferme la dernière row
    } else {
        echo "<p class='text-white text-center'>Aucune voiture disponible.</p>";
    }

    mysqli_close($bdd);
    ?>
</div>

    <?php include 'footer.php'; ?>
</body>
</html>
