<!DOCTYPE HTML>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modification Client</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href = "a_style_menu.css" rel="stylesheet">
</head>
<body>

<?php
// Inclusion du fichier de connexion à la base de données
include("connexion.php");

// Vérification et traitement de la soumission du formulaire
if(isset($_POST['update']))
{   
    // Récupération des valeurs du formulaire
    $id_inscription = $_POST["id_inscription"]; 
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $email = $_POST['email'];  
    $numero = $_POST['numero'];
    $username = $_POST['username'];  

    // Exécution de la requête SQL pour mettre à jour les données
    $result = mysqli_query($bdd, "UPDATE inscription SET nom='$nom', prenom='$prenom', email='$email', numero='$numero', username='$username' WHERE id_inscription=$id_inscription");
    
    // Redirection après la mise à jour
    if($result) {
        header("Location: a_client_modifier.php");
        exit; // Assurez-vous de terminer le script après la redirection
    } else {
        echo "Erreur lors de la mise à jour.";
    }
}

// Récupération de l'identifiant depuis l'URL
$id_inscription = $_GET['id_inscription'];
 
// Récupération des données associées à cet identifiant
$result = mysqli_query($bdd, "SELECT * FROM inscription WHERE id_inscription=$id_inscription");

// Initialisation des variables
$nom = $prenom = $email = $numero = $username = $password = '';

// Lecture des données
if(mysqli_num_rows($result) > 0) {
    $res = mysqli_fetch_assoc($result);
    $nom = $res['nom'];
    $prenom = $res['prenom'];
    $email = $res['email'];  
    $numero = $res['numero'];
    $username = $res['username'];  
    $password = $res['password'];
}
?>

<div class="container one p-5">
    <a href="a_client_modifier.php">Retour</a>
    <h4 class="text-center fw-bold">Modification</h4>
    <form name="form1" method="post" action="a_client_modif.php" class="mt-4">
        <input type="hidden" name="id_inscription" value="<?php echo $id_inscription; ?>">

                <label for="nom" class="form-label mt-3">Nom</label>
                <input type="text" name="nom" class="form-control" value="<?php echo $nom; ?>" required>

            <div class="mb-3">
                <label for="prenom" class="form-label">Prénom</label>
                <input type="text" name="prenom" class="form-control" value="<?php echo $prenom; ?>">
            </div>

                <label for="email" class="form-label mt-3">Email</label>
                <input type="email" name="email" class="form-control" value="<?php echo $email; ?>">

                <label for="numero" class="form-label mt-3">Numéro</label>
                <input type="number" name="numero" class="form-control" value="<?php echo $numero; ?>">


                <label for="username" class="form-label mt-3">Username</label>
                <input type="text" name="username" class="form-control" value="<?php echo $username; ?>">
                <button type="submit" name="update" class="form-control button mt-4 red">Mettre à jour</button>       
    </form>
</div>

</body>
</html>
