<!DOCTYPE HTML>
<HTML>
<HEAD>
<meta charset = "UTF-8">
<meta name = "viewport" content = "width = device-width, initial-scale = 1.0">
<title> Modification Accueil </title>
 
    <!--CSS de Bootstrap-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
 
    <!--JAVASCRIPT de Bootstrap-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
<link href = "a_style_menu.css" rel="stylesheet">


</HEAD>

<body>

<?php
include("connexion.php");
 
if(isset($_POST['update']))
{   
    $identifiant = $_POST["identifiant"]; 
    $QSN = $_POST['QSN'];
    $QFN = $_POST['QFN'];
    $image1 = $_POST['image1'];  
    $image2 = $_POST['image2'];

    $image11 = $_POST['image11']; 
    $image111 = 'images/' . $image11;

    $image22 = $_POST['image22'];
    $image222 = 'images/' . $image22;    
 
        
    // vérifier les champs vides
    if(empty($QSN) || empty($QFN)) {            
        if(empty($QSN)) {
            echo "<font color='red'>Name field is empty.</font><br/>";
        }
        if(empty($QFN)) {
            echo "<font color='red'>Age field is empty.</font><br/>";
        }
    } else {    
        //mise à jour de la table
        $result = mysqli_query($bdd, "UPDATE p_accueil SET QSN='$QSN', QFN='$QFN', image1='$image111', image2='$image222' WHERE identifiant=$identifiant");
        
        //rediriger la page d'accueil. Dans notre cas c'est la page index.php
        header("Location: a_accueil_modifier.php");
    }
}

//récupérer l'identifiant depuis l'URL
$identifiant = $_GET['identifiant'];
 
//extraction des données associées avec cet identifiant particulier
$result = mysqli_query($bdd, "SELECT * FROM p_accueil WHERE identifiant=$identifiant");

// lecture du curseur 
while($res = mysqli_fetch_array($result))
{   
    //assigner les valeurs des colonnes de la base de données aux variables
    $QSN = $res['QSN'];
    $QFN = $res['QFN'];
    $image1 = $res['image1'];  
    $image2 = $res['image2'];
}
?>
<html>
<body>
<div class="container one p-5">
    <div class="mb-3 p-5">
        <a href="a_accueil_modifier.php">Retour</a>
        <h4 class="text-center fw-bold">Modification</h4>
</br></br>
            <form name="form1" method="post" action="a_accueil_modif.php">
                <div class="mb-3">
                    <label for="QSN" class="form-label">Voulez-vous changer le texte de Qui Sommes-Nous ?</label>
                    <textarea name="QSN" class="form-control" rows="5"><?php echo $QSN; ?></textarea>
                </div>
                <div class="mb-3">
                    <label for="QFN" class="form-label">Voulez-vous changer le teste de que Faisons-Nous ?</label>
                    <textarea name="QFN" class="form-control" rows="5"><?php echo $QFN; ?></textarea>
                </div>
                <div class="mb-3">
                    <label for="image1" class="form-label">Voulez-vous changer l'image de Qui Sommes-Nous ? </label>
                    <input type="text" class="form-control" id="image1" name="image1" value="<?php echo $image1; ?>">
                </div>
                <div class="mb-3">
                    <label for="inputGroupFile02" class="form-label">Télécharger l'image</label>
                    <input type="file" class="form-control" name="image11" required>
                </div>
                <div class="mb-3">
                    <label for="image2" class="form-label">Voulez-vous l'image de que Faisons-Nous ?</label>
                    <input type="text" class="form-control" id="image2" name="image2" value="<?php echo $image2; ?>">
                </div>
                <div class="mb-3">
                    <label for="inputGroupFile02" class="form-label">Télécharger l'image</label>
                    <input type="file" class="form-control" name="image22" required>
                </div>
                <input type="hidden" name="identifiant" value="<?php echo $identifiant; ?>">
                <button type="submit" name="update" class="form-control button mt-4 red">Mettre à jour</button>
           </form>
    </div>
</div>
</body>
</html>
