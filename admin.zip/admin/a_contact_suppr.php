<?php 
include("connexion.php");
$id_message = $_GET['id_message'];
$result = mysqli_query($bdd, "DELETE FROM contact WHERE id_message=$id_message");
header("Location:a_contact_supprimer.php");
?>
