<!DOCTYPE HTML>
<HTML>
<HEAD>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title> Demandes de service </title>
 
    <!-- CSS de Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
 
    <!-- JAVASCRIPT de Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
 
    <link href="a_style_menu.css" rel="stylesheet">
</HEAD>
<BODY>
 
<div class="container one p-5">
<a href="a_menu_demande_service.html">Retour</a>
 
    <!-- Partie PHP -->
    <?php
    include("connexion.php");
    $result = mysqli_query($bdd, "SELECT * FROM service ORDER BY id_service ASC");
    ?>
 
    <!-- Fin du PHP -->
 
    <table class="table">
      <thead>
        <tr>
          <th>Identifiant</th>
          <th>Type du service</th>
          <th>Date du service</th>
          <th> Statut </th>
        </tr>
      </thead>
      <tbody>
      <?php 
      // Requête pour récupérer les données après la suppression
      $result = mysqli_query($bdd, "SELECT id_service, type_service, date_service, statut_service FROM service");
      while ($res = mysqli_fetch_array($result)) {         
          echo "<tr>";
          echo "<td>".$res['id_service']."</td>";
          echo "<td>".$res['type_service']."</td>";
          echo "<td>".$res['date_service']."</td>"; 
          echo "<td>".$res['statut_service']."</td>"; 
          echo "</tr>";
      }
      ?>
      </tbody>
    </table>
</div>     

</BODY>
</HTML>
