<!DOCTYPE HTML>
<HTML>
<HEAD>
<meta charset = "UTF-8">
<meta name = "viewport" content = "width = device-width, initial-scale = 1.0">
<TITLE> Authentification </TITLE>
 
    <!--CSS de Bootstrap-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
 
    <!--JAVASCRIPT de Bootstrap-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
 
    <link href = "a_style_login.css" rel="stylesheet">
</HEAD>
 
<BODY>
<?php
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
 
    // Define your database connection credentials
    include("connexion.php");
 
    // Function to validate login
    function validateLogin($bdd, $username, $password) {
        // Hash the password with MD5
        $hashed_password = md5($password);
 
        // Use prepared statements to prevent SQL injection
        $stmt = $bdd->prepare("SELECT id_admin FROM ADMINISTRATEUR WHERE username = ? AND password = ?");
        $stmt->bind_param("ss", $username, $hashed_password);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();
 
        if ($result->num_rows > 0) {
            return true; // Valid login
        } else {
            return false; // Invalid login
        }
    }
 
    // Handle form submission
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = $_POST["username"];
        $password = $_POST["mdp"];
 
        // Validate login
        if (validateLogin($bdd, $username, $password)) {
            session_start();
            $_SESSION['username'] = $usrname;
            // Redirect to the homepage
            header("Location: a_menu.html");
            exit(); // Ensure the script stops after redirection
        } else {
            $status = "Nom d'utilisateur ou mot de passe incorrect.";
        }
 
        // Close the database connection
        $bdd->close();
    }
 
    // Initialize the status variable
?>
 
<div class="container">
<form class="form-group" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
<div class="mb-3 bg p-5">
<h2 class="text-center fw-bold"> Login </h2>
<label for="username" class="form-label mt-5">Nom d'utilisateur</label>
<input type="text" class="form-control" name="username" placeholder="Nom d'utilisateur" required>
 
            <label for="mdp" class="form-label mt-3">Mot de passe</label>
<input type="password" class="form-control" name="mdp" placeholder="Mot de passe" required>
 
            <button type="submit" class="form-control button mt-4 mb-3 btn">Connexion</button>
</div>
<div id="status">
<?php
            // Display status message in the dedicated field
            if (isset($status)) {
                echo $status;
            }
        ?>
</div>
</form>
</div>
 
</BODY>
</HTML>