<?php 
include("connexion.php");
$identifiant = $_GET['identifiant'];
$result = mysqli_query($bdd, "DELETE FROM p_service WHERE identifiant=$identifiant");
header("Location:a_service_supprimer.php");
?>