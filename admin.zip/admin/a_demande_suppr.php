<?php 
include("connexion.php");
$id_demande = $_GET['id_demande'];
$result = mysqli_query($bdd, "DELETE FROM demande_essai WHERE id_demande=$id_demande");
header("Location:a_demande_modifier.php");
?>