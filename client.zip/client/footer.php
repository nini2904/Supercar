<style>
footer {
    background-color: #111; /* fond noir */
    color: white;
    text-align: center;
    font-size: 14px;
    padding-top: 20px;
    padding-bottom: 20px;
}

footer a {
    color: #3498db;
    text-decoration: none;
}

footer a:hover {
    text-decoration: underline;
}
</style>

<footer>
    <div>
        <small>Supercar &copy; Copyright by Supercar</small>
    </div>
    <div class="container">
        <div class="row justify-content-center mt-3">
            <div class="col-md-4 text-center">
                <a href="mentionlegale.php">Mentions Légales</a>
            </div>
            <div class="col-md-4 text-center">
                <a href="politiqueconf.php">Politique de confidentialité</a>
            </div>
            <div class="col-md-4 text-center">
                <a href="contact.php">Contact</a>
            </div>
        </div>
    </div>
</footer>
