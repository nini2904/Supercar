<?php
session_name("supercar_session"); // Pour Supercar
session_start();
session_destroy(); // Supprime toutes les sessions
setcookie('login_token', '', time() - 3600, '/'); // Supprime le cookie de connexion (si utilisé)
header("Location: index.php"); // Redirige vers la page d'accueil
exit();
