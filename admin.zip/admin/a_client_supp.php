<?php 
include("connexion.php");
$id_inscription = $_GET['id_inscription'];
$result = mysqli_query($bdd, "DELETE FROM inscription WHERE id_inscription =$id_inscription");
header("Location: a_client_supprimer.php");
?>