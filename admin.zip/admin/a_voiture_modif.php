<!DOCTYPE HTML>
<HTML>
<HEAD>
<meta charset = "UTF-8">
<meta name = "viewport" content = "width = device-width, initial-scale = 1.0">
<title> Modification Voiture </title>

<!--CSS de Bootstrap-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

<!--JAVASCRIPT de Bootstrap-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

<link href = "a_style_menu.css" rel="stylesheet">
</HEAD>
<BODY>

<?php
include("connexion.php");

$error_message = "";

// Traitement du formulaire lorsque l'utilisateur clique sur "Update"
if(isset($_POST['update'])) {

    // Récupération des données du formulaire
    $id_voiture = htmlspecialchars($_POST['id_voiture']);
    $marque = htmlspecialchars($_POST['marque']);
    $modele = htmlspecialchars($_POST['modele']);
    $annee = htmlspecialchars($_POST['annee']);
    $mini_description = htmlspecialchars($_POST['mini_description']);
    $vitesse = htmlspecialchars($_POST['vitesse']);
    $prix = htmlspecialchars($_POST['prix']);
    

    // Gestion des images (vérification si une nouvelle image a été uploadée)
    $image_front2 = !empty($_FILES['image_front1']['name']) ? 'images/' . $_FILES['image_front1']['name'] : htmlspecialchars($_POST['image_front']);
    $image_profile2 = !empty($_FILES['image_profile1']['name']) ? 'images/' . $_FILES['image_profile1']['name'] : htmlspecialchars($_POST['image_profile']);

    // Vérification des champs obligatoires
    if(empty($marque) || empty($modele) || empty($annee) || empty($mini_description) || empty($vitesse) || empty($prix)) {
        $error_message = "All fields are required.";
    } else {
        // Préparation de la requête SQL de mise à jour
        $stmt = mysqli_prepare($bdd, "UPDATE voiture SET marque=?, modele=?, annee=?, mini_description=?, vitesse=?, prix=?, image_front=?, image_profile=? WHERE id_voiture=?");
        mysqli_stmt_bind_param($stmt, "ssssssssi", $marque, $modele, $annee, $mini_description, $vitesse, $prix, $image_front2, $image_profile2, $id_voiture);

        // Exécution de la requête SQL
        if(mysqli_stmt_execute($stmt)) {
            // Déplacer les fichiers uploadés vers le dossier images
            if (!empty($_FILES['image_front1']['name'])) {
                move_uploaded_file($_FILES['image_front1']['tmp_name'], $image_front2);
            }
            if (!empty($_FILES['image_profile1']['name'])) {
                move_uploaded_file($_FILES['image_profile1']['tmp_name'], $image_profile2);
            }

            // Fermeture de la requête et redirection
            mysqli_stmt_close($stmt);
            header("Location: a_voiture_modifier.php");
            exit();
        } else {
            $error_message = "Failed to update the vehicle.";
        }

        mysqli_stmt_close($stmt);
    }
}

// Vérification si l'ID de voiture est présent dans l'URL
if(isset($_GET['id_voiture'])) {
    $id_voiture = htmlspecialchars($_GET['id_voiture']);
    $result = mysqli_query($bdd, "SELECT * FROM voiture WHERE id_voiture=$id_voiture");

    // Vérifier si la voiture existe
    if(mysqli_num_rows($result) == 0) {
        echo "Vehicle not found.";
        exit();
    }

    // Extraction des données de la voiture
    $res = mysqli_fetch_array($result);
    $marque = htmlspecialchars($res['marque']);
    $modele = htmlspecialchars($res['modele']);
    $annee = htmlspecialchars($res['annee']);
    $mini_description = htmlspecialchars($res['mini_description']);
    $image_front = htmlspecialchars($res['image_front']);
    $image_profile = htmlspecialchars($res['image_profile']);
    $vitesse = htmlspecialchars($res['vitesse']);
    $prix = htmlspecialchars($res['prix']);
} else {
    echo "ID de voiture manquant.";
    exit();
}
?>

<div class="container one p-4">
    <a href="a_voiture_modifier.php">Retour</a>
    <h4 class="text-center fw-bold">Modification</h4>

    <!-- Formulaire de modification -->
    <form name="form1" method="post" action="a_voiture_modif.php" enctype="multipart/form-data" class="mt-4">
        <div class="row mb-3">
            <div class="col-md-4">
                <label for="marque" class="form-label">Marque</label>
                <input type="text" name="marque" class="form-control" value="<?php echo $marque; ?>" required>
            </div>

            <div class="col-md-4">
                <label for="modele" class="form-label">Modèle</label>
                <input type="text" name="modele" class="form-control" value="<?php echo $modele; ?>">
            </div>

            <div class="col-md-4">
                <label for="annee" class="form-label">Année</label>
                <input type="number" name="annee" class="form-control" value="<?php echo $annee; ?>">
            </div>

            <div class="mb-3">
                <label for="mini_description" class="form-label">Mini Description</label>
                <textarea name="mini_description" class="form-control" rows="5"><?php echo $mini_description; ?></textarea>
            </div>

            <!-- Gestion des images -->
            <div class="col-md-6">
                <label for="image_front" class="form-label">Image Front (actuelle)</label>
                <input type="text" class="form-control" id="image_front" name="image_front" value="<?php echo $image_front; ?>" readonly>
                <input type="file" class="form-control mt-2" name="image_front1">
            </div>

            <div class="col-md-6">
                <label for="image_profile" class="form-label">Image Profil (actuelle)</label>
                <input type="text" class="form-control" id="image_profile" name="image_profile" value="<?php echo $image_profile; ?>" readonly>
                <input type="file" class="form-control mt-2" name="image_profile1">
            </div>

            <!-- Autres champs -->
            <div class="col-md-6">
                <label for="vitesse" class="form-label">Vitesse</label>
                <input type="text" name="vitesse" class="form-control" value="<?php echo $vitesse; ?>" required>
            </div>

            <div class="col-md-6">
                <label for="prix" class="form-label">Prix</label>
                <input type="text" name="prix" class="form-control" value="<?php echo $prix; ?>" required>
            </div>

            <!-- Champ caché pour l'id de la voiture -->
            <input type="hidden" name="id_voiture" value="<?php echo $id_voiture; ?>">

            <!-- Bouton de mise à jour -->
            <div class="col-12 mt-4">
                <button type="submit" name="update" class="form-control button red">Update</button>
            </div>
        </div>
    </form>

    <!-- Affichage d'un message d'erreur si nécessaire -->
    <?php if(!empty($error_message)) { ?>
        <div class="alert alert-danger mt-3"><?php echo $error_message; ?></div>
    <?php } ?>
</div>
</body>
</html>
