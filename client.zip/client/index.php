
<?php
include("connexion.php");


?>




<!DOCTYPE html>
<html lang="en">
<head>
  <title>Supercar</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <link href="accueil.css" rel="stylesheet">
</head>
<body>

<!-- Navbar -->
<?php include 'navbar.php'; ?>

<!-- Première section avec vidéo -->
<section class="position-relative">
  <div class="overlay"></div>
    <video autoplay muted loop playsinline class="background-video">
      <source src="videos/route.mp4" type="video/mp4">
    </video>
  <div class="content text-center">
    <div class="split-text-container" style="padding-left: 10px;">
      <span class="text-part left">SUPER</span>
      <span class="text-part right">CAR</span>
    </div>
    <p>Votre site idéal qui vous offre une large gamme de voitures SUPERCAR</p>
    <a href="#presentation" class="button">More</a>
  </div>
</section>

<!-- Deuxième section -->
<section id="presentation">
<?php
$selection = "SELECT * FROM p_accueil WHERE Identifiant = '1'";
$curseur = mysqli_query($bdd, $selection);

if ($curseur) {
    if (mysqli_num_rows($curseur) > 0) {
        while ($row = mysqli_fetch_array($curseur)) {
            $QSN = $row["QSN"];
            $QFN = $row["QFN"];
            $image1 = $row["image1"];
            $image2 = $row["image2"];

            echo "<div class='container mt-5 mb-5'>";
            echo "<div class='row align-items-center mb-5'>";
            echo "<div class='col-md-5 text-center'>";
            echo "<img src='$image1' alt='Image Qui sommes-nous' class='img-fluid'>";
            echo "</div>";
            echo "<div class='col-md-7 milieu p-5 rounded shadow'>";
            echo "<h5>Qui sommes-nous ?</h5>";
            echo "<p>$QSN</p>";
            echo "</div>";
            echo "</div>";

            echo "<div class='row align-items-center'>";
            echo "<div class='col-md-7 milieu p-5 rounded shadow'>";
            echo "<h5>Que faisons-nous ?</h5>";
            echo "<p>$QFN</p>";
            echo "</div>";
            echo "<div class='col-md-5'>";
            echo "<img src='$image2' alt='Image Que faisons-nous' class='img-fluid'>";
            echo "</div>";
            echo "</div>";
            echo "</div>";

            
        }
        mysqli_free_result($curseur);
    } else {
        echo "Aucun résultat trouvé.";
    }
} else {
    echo "Erreur de requête : " . mysqli_error($bdd);
}
?>
</section>


</body>

<!-- Footer -->
<?php include 'footer.php'; ?>
