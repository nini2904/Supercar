<!DOCTYPE HTML>
<HTML>
<HEAD>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- CSS de Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <!-- JavaScript de Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <link href="services.css" rel="stylesheet">
    <title>Services</title>
</HEAD>

<BODY>

<?php include 'navbar.php'; ?>
<?php include("connexion.php"); ?>

<!-- Affichage des services -->
<?php
$selection = "SELECT image, type_service, description_service FROM p_service";
$curseur = mysqli_query($bdd, $selection);

// Utiliser une <div> avec classe de marge ou padding pour éviter que le titre soit masqué
echo "<div class='mt-5 pt-5 text-center'>";
echo "<h1>Nos Services</h1>";
echo "</div>";

if ($curseur) {
    if (mysqli_num_rows($curseur) > 0) {
        while ($row = mysqli_fetch_array($curseur)) {
            $v_image = $row["image"];
            $v_type_service = $row["type_service"];
            $v_description = $row["description_service"];

            echo "<div class='d-flex justify-content-center'>";

            echo "<div class='card' style='margin: 20px; max-width: 1000px;'>";
            echo "<img src='$v_image' class='img-fluid rounded-top' alt='Service Image' style='max-height: 300px; object-fit: cover;'>";
            echo "<div class='card-body text-center' style='padding: 20px 10px;'>";
            echo "<h5>$v_type_service</h5>";
            echo "<p>$v_description</p>";
            echo "<button class='btn btn-primary demander-service' data-bs-toggle='modal' data-bs-target='#serviceModal' data-service='" . htmlspecialchars($v_type_service) . "'>Demander ce service</button>";
            echo "</div>";
            echo "</div>";
            echo "</div>";
        }

        mysqli_free_result($curseur);
    } else {
        echo "<p class='text-center'>Aucun résultat trouvé.</p>";
    }
} else {
    echo "<p class='text-danger text-center'>Erreur de requête : " . mysqli_error($bdd) . "</p>";
}
?>


<!-- Traitement du formulaire -->
<?php
function validateLogin($bdd, $username, $password, $p_field_type, $p_date) {
    $stmt = $bdd->prepare("SELECT id_inscription FROM INSCRIPTION WHERE username = ? AND password = ?");
    $hashpassword = md5($password);
    $stmt->bind_param("ss", $username, $hashpassword);
    $stmt->execute();
    $result = $stmt->get_result();
    $status1 = '';

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $id_inscription = $row['id_inscription'];

        $stmtInsert = $bdd->prepare("INSERT INTO service (type_service, date_service, id_inscription) VALUES (?, ?, ?)");
        if ($stmtInsert === false) {
            die("Prepare failed: " . htmlspecialchars($bdd->error));
        }
        $success = $stmtInsert->bind_param("ssi", $p_field_type, $p_date, $id_inscription);
        if ($success === false) {
            die("Binding parameters failed: " . htmlspecialchars($stmtInsert->error));
        }
        if ($stmtInsert->execute()) {
            $status1 .= "Données insérées avec succès !";
        } else {
            $status1 .= "Échec de l'insertion des données. Erreur : " . $stmtInsert->error;
        }
        $stmtInsert->close();

        return true;
    } else {
        return false;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $mdp = $_POST["mdp"];
    $date = $_POST["date_service"];
    $field_type = $_POST["field_type"];

    if (validateLogin($bdd, $username, $mdp, $field_type, $date)) {
        $status = "Connexion réussie !";
    } else {
        $status = "Nom d'utilisateur ou mot de passe incorrect.";
    }

    $bdd->close();
}
?>

<!-- Modal pour la demande de service -->
<div class="modal fade" id="serviceModal" tabindex="-1" aria-labelledby="serviceModalLabel" aria-hidden="true">
    <div class="modal-dialog text-black">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-center" id="serviceModalLabel">Envoyez votre demande de service</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form class="form-group" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <div class="mb-2">
                        <p class="text-center">
                            <em>Veuillez noter que vous devez être client chez Supercar avant de procéder à une demande de service</em>
                            <a class="text-center" href="inscription.php">Faites votre inscription</a>
                        </p>
                        <hr size="10" color="black">

                        <div class="row mb-3">
                            <div class="col">
                                <label for="username" class="form-label mt-3">Nom d'utilisateur</label>
                                <input type="text" class="form-control" name="username" required>
                            </div>
                            <div class="col">
                                <label for="password" class="form-label mt-3">Mot de passe</label>
                                <input type="password" class="form-control" name="mdp" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col">
                                <label for="date" class="form-label mt-2">Date pour votre rendez-vous</label>
                                <input type="date" name="date_service" class="form-control" required>
                            </div>
                            <div class="col">
                                <label for="field_type" class="form-label mt-2">Service de votre choix</label>
                                <input type="text" name="field_type" id="field_type" class="form-control" readonly required>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col">
                                <button type="submit" class="form-control button mt-5 btn">Envoyer</button>
                            </div>
                            <div class="col">
                                <button type="reset" class="form-control button mt-5 btn">Annuler</button>
                            </div>
                        </div>

                        <div id="status">
                            <?php if (isset($status)) echo $status; ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Script pour remplir automatiquement le champ service -->
<script>
    document.addEventListener("DOMContentLoaded", function() {
        let buttons = document.querySelectorAll(".demander-service");

        buttons.forEach(button => {
            button.addEventListener("click", function() {
                let serviceType = this.getAttribute("data-service");
                document.getElementById("field_type").value = serviceType;
            });
        });
    });
</script>

<?php include 'footer.php'; ?>

</BODY>
</HTML>
