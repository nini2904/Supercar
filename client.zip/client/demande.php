<HTML>
<HEAD>
    <meta charset = "UTF-8">
    <meta name = "viewport" content = "width = device-width, initial-scale = 1.0">

    <!--CSS de Bootstrap-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <!--JAVASCRIPT de Bootstrap-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link href = "demande.css" rel="stylesheet">
    <title> Demande d'essai </title>

</HEAD>

<BODY>

    <!--DEBUT NAVBAR-->
    <?php include 'navbar.php'; ?>
    <!--FIN NAVBAR-->

<?php
    // Define your database connection credentials
 include("connexion.php");

    // Function to validate login
    function validateLogin($bdd, $username, $password,$p_field_modele,$p_date,$p_heure_demande) {
        // Use prepared statements to prevent SQL injection
        $stmt = $bdd->prepare("SELECT id_inscription FROM INSCRIPTION WHERE username = ? AND password = ?");
        $hashpassword = md5($password);
        $stmt->bind_param("ss", $username, $hashpassword);
        $stmt->execute();
        $result = $stmt->get_result();
         $status1 ='';

        if ($result->num_rows > 0) {

            $row = $result->fetch_assoc();
            $id_inscription = $row['id_inscription'];

                $stmtInsert = $bdd->prepare("INSERT INTO DEMANDE_ESSAI (date_demande, heure_demande, id_inscription, id_voiture) VALUES (?, ?, ?, ?)");

                // Bind parameters
                $stmtInsert->bind_param("ssii", $p_date, $p_heure_demande, $id_inscription, $p_field_modele);


                 //Exécuter la requête
                 if ($stmtInsert->execute()) {
                        $status1 .= " Données insérées avec succès !";
                 } else {
                        $status1 .= " Échec de l'insertion des données. Erreur : " . $stmtInsert->error;
                  }
                  $stmtInsert->close();

            return true; // Valid login
        } else {
            return false; // Invalid login
        }
    }

    // Handle form submission
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $mdp = $_POST["mdp"];
    $date = $_POST["date"];
    $heure_demande = $_POST["heure_demande"];
    $field_modele = $_POST["field_modele"];

    // Valider la connexion
    if (validateLogin($bdd, $username, $mdp, $field_modele,$date,$heure_demande)) {
        $status = "Connexion réussie !";

    } else {
        $status = "Nom d'utilisateur ou mot de passe incorrect.";
    }

    // Fermer la connexion à la base de données
    $bdd->close();
}
?>


<div class="container-fluid">
    <form class="form-group" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <div class="mb-3 bg p-5">
            <h2 class="text-center fw-bold"> Envoyez-nous votre demande d'essai </h2>
            <p class="text-center"><em>Veuillez noter que vous devez être client chez Supercar avant de procéder à une demande d'essai</em>
                <a class="text-center" href= "inscription.php"> Faites votre inscription </a>
            </p>
            <hr size=10 color="black">
            
            <div class="row mb-3">
                <div class="col">
                    <label for="username" class="form-label mt-3">Nom d'utilisateur</label>
                    <input type="text" class="form-control" name="username" required>
                </div>
                <div class="col">
                    <label for="password" class="form-label mt-3">Mot de passe</label>
                    <input type="password" class="form-control" name="mdp" required>
                </div>
            </div>
            
            <div class="row mb-3">
                <div class="col">
                    <label for="date" class="form-label mt-2">Date pour votre rendez-vous</label>
                    <input type="date" name="date" class="form-control" required>
                </div>
                <div class="col">
                    <?php
                    // Include the database connection file
                    include("connexion.php");

                    // Prepare and execute the query to select car models
                    $selection = "SELECT id_voiture, marque, modele FROM VOITURE";
                    $curseur = mysqli_query($bdd, $selection);

                    // Check if the query executed successfully
                    if ($curseur) {
                        echo "<label for='field_modele' class='form-label mt-2'>Voiture de votre choix</label>";
                        echo "<select name='field_modele' class='form-control' required>";
                        echo "<option value=''>...</option>";
                        
                        // Loop through results to populate the dropdown
                        while ($row = mysqli_fetch_array($curseur)) {
                            $modele = $row["modele"];
                            $marque = $row["marque"];
                            $v_id_voiture = $row["id_voiture"];
                            echo "<option value='$v_id_voiture'>$marque $modele</option>";
                        }

                        echo "</select>";
                    } else {
                        // Display error message if query fails
                        echo "Erreur lors de l'exécution de la requête : " . mysqli_error($bdd);
                    }

                    // Close the database connection
                    mysqli_close($bdd);
                    ?>
                </div>
            </div>

            <div class="row mb-3">
                <div class="col">
                    <label for="heure_demande" class="form-label">Heure de votre rendez-vous</label>
                    <input type="time" name="heure_demande" class="form-control" min="08:00" max="17:00" required>
                </div>
            </div>

            <div class="row">
                <div class="col">
                    <button type="submit" class="form-control button mt-5 btn">Envoyer</button>
                </div>
                <div class="col">
                    <button type="reset" class="form-control button mt-5 btn">Annuler</button>
                </div>

            </div>
        </div>

        <div id="status">
            <?php
            // Display status message
            if (isset($status)) {
                echo $status;
            }
            ?>
        </div>
    </form>
</div>

<?php include 'footer.php'; ?>

</body>
</html>