
<?php 
if (session_status() == PHP_SESSION_NONE) {
    session_name("supercar_session"); // Pour Supercar
    session_start();
}
?>
<!DOCTYPE HTML>

<HTML>
<HEAD>
    <meta charset = "UTF-8">
    <meta name = "viewport" content = "width = device-width, initial-scale = 1.0">

<!-- Fonts Google -->
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500&family=Poppins:wght@400;600&display=swap" rel="stylesheet">

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link href = "navbar.css" rel="stylesheet">
</HEAD>

<nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top p-2">
    <a class="navbar-brand text-danger fw-bold" href="index.php">
    <img src="images/logo_supercar.png" alt="logo" width="40" style="filter: brightness(0) invert(1);">
    SUPERCAR
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav mx-auto">
            <li class="nav-item"><a class="nav-link" href="index.php">Accueil</a></li>
            <li class="nav-item"><a class="nav-link" href="voiture.php">Voitures</a></li>
            <li class="nav-item"><a class="nav-link" href="demande.php">Demande d'essai</a></li>
            <li class="nav-item"><a class="nav-link" href="services.php">Services</a></li>
            <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
        </ul>

        <ul class="navbar-nav">
            <?php if (isset($_SESSION['id_inscription'])): ?>
                <li class="nav-item">
                    <a class="nav-link" href="#">
                        <i class="fa fa-user"></i> 
                        <?php echo strtoupper($_SESSION['prenom']); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-danger fw-bold" onclick="confirmDeconnexion()" href="#">Déconnexion</a>
                </li>
            <?php else: ?>
                <li class="nav-item">
                    <a class="nav-link" href="inscription.php">Inscription</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="login.php"><i class="fa fa-user"></i> Connexion</a>
                </li>
            <?php endif; ?>
        </ul>
    </div>
</nav>

<script>
function confirmDeconnexion() {
    if (confirm("Voulez-vous vraiment vous déconnecter ?")) {
        window.location.href = "logout.php";
    }
}
</script>
