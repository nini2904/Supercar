<?php
include("connexion.php");

// Requête SQL pour regrouper les données selon les statuts et les mois
$query = "
    SELECT 
        DATE_FORMAT(d.date_demande, '%M') AS Mois,       -- Nom du mois
        YEAR(d.date_demande) AS Annee,                 -- Année
        SUM(CASE WHEN d.statut_demande = 'En attente' THEN 1 ELSE 0 END) AS `En attente`,
        SUM(CASE WHEN d.statut_demande = 'Confirmé' THEN 1 ELSE 0 END) AS `Confirmé`,
        SUM(CASE WHEN d.statut_demande = 'Terminé' THEN 1 ELSE 0 END) AS `Terminé`,
        SUM(CASE WHEN d.statut_demande = 'Annulé' THEN 1 ELSE 0 END) AS `Annulé`
    FROM DEMANDE_ESSAI d
    GROUP BY Annee, Mois
    ORDER BY Annee ASC, MONTH(d.date_demande) ASC;
";

$result = mysqli_query($bdd, $query);

?>

<!DOCTYPE HTML>
<HTML>
<HEAD>
<meta charset = "UTF-8">
<meta name = "viewport" content = "width = device-width, initial-scale = 1.0">
<title> Statistiques Demandes d'Essai </title>
 
    <!--CSS de Bootstrap-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
 
    <!--JAVASCRIPT de Bootstrap-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
 
    <link href = "a_style_menu.css" rel="stylesheet">
</HEAD>
<BODY>
 
<div class="container one p-5">
<a href="a_menu_demande.html">Retour</a>
    <table>
      <thead>
        <tr>
          <th>Mois</th>
          <th>Année</th>
          <th>En attente</th>
          <th>Confirmé</th>
          <th>Terminé</th>
          <th>Annulé</th>
        </tr>
      </thead>
      <tbody>

<?php 
// Parcourir les résultats et afficher les données dans le tableau
while ($row = mysqli_fetch_assoc($result)) {
    $mois = htmlspecialchars($row['Mois']);
    $annee = (int)$row['Annee'];
    $en_attente = (int)$row['En attente'];
    $confirme = (int)$row['Confirmé'];
    $termine = (int)$row['Terminé'];
    $annule = (int)$row['Annulé'];

    echo "<tr>";
    echo "<td>$mois</td>";
    echo "<td>$annee</td>";
    echo "<td>$en_attente</td>";
    echo "<td>$confirme</td>";
    echo "<td>$termine</td>";
    echo "<td>$annule</td>";
    echo "</tr>";
}
?>

      </tbody>
    </table>
</div>     
 
</BODY>
</HTML>
