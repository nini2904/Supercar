<!DOCTYPE HTML>
<HTML>
<HEAD>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modification Accueil</title>
 
    <!--CSS de Bootstrap-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
 
    <!--JAVASCRIPT de Bootstrap-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link href="a_style_menu.css" rel="stylesheet">
</HEAD>
 
<body>
 
<?php
include("connexion.php");
 
$error_message = "";
 
// Traitement du formulaire lorsque l'utilisateur clique sur "Update"
if(isset($_POST['update'])) {
    $identifiant = htmlspecialchars($_POST["identifiant"]);
    $QSN = htmlspecialchars($_POST['QSN']);
    $QFN = htmlspecialchars($_POST['QFN']);
    $image1 = htmlspecialchars($_POST['image1']);
    $image2 = htmlspecialchars($_POST['image2']);
 
    // Gestion des images uploadées
    $image11 = !empty($_FILES['image11']['name']) ? 'images/' . $_FILES['image11']['name'] : htmlspecialchars($_POST['image1']);
    $image22 = !empty($_FILES['image22']['name']) ? 'images/' . $_FILES['image22']['name'] : htmlspecialchars($_POST['image2']);
 
    // Vérification des champs obligatoires
    if(empty($QSN) || empty($QFN)) {
        $error_message = "Tous les champs sont obligatoires.";
    } else {
        // Mise à jour des données dans la base
        $result = mysqli_query($bdd, "UPDATE p_accueil SET QSN='$QSN', QFN='$QFN', image1='$image11', image2='$image22' WHERE identifiant=$identifiant");
 
        // Déplacer les fichiers uploadés vers le dossier images
        if (!empty($_FILES['image11']['name'])) {
            move_uploaded_file($_FILES['image11']['tmp_name'], $image11);
        }
        if (!empty($_FILES['image22']['name'])) {
            move_uploaded_file($_FILES['image22']['tmp_name'], $image22);
        }
 
        // Redirection après la mise à jour
        header("Location: a_accueil_modifier.php");
        exit();
    }
}
 
// Récupération de l'identifiant depuis l'URL
$identifiant = htmlspecialchars($_GET['identifiant']);
 
// Extraction des données associées à cet identifiant
$result = mysqli_query($bdd, "SELECT * FROM p_accueil WHERE identifiant=$identifiant");
$res = mysqli_fetch_array($result);
 
$QSN = htmlspecialchars($res['QSN']);
$QFN = htmlspecialchars($res['QFN']);
$image1 = htmlspecialchars($res['image1']);
$image2 = htmlspecialchars($res['image2']);
?>
 
<div class="container one p-5">
    <div class="mb-3 p-5">
        <a href="a_accueil_modifier.php">Retour</a>
        <h4 class="text-center fw-bold">Modification</h4>
 
        <!-- Formulaire de modification -->
        <form name="form1" method="post" action="a_accueil_modif.php" enctype="multipart/form-data" class="mt-4">
            <div class="mb-3">
                <label for="QSN" class="form-label">Voulez-vous changer le texte de Qui Sommes-Nous ?</label>
                <textarea name="QSN" class="form-control" rows="5"><?php echo $QSN; ?></textarea>
            </div>
 
            <div class="mb-3">
                <label for="QFN" class="form-label">Voulez-vous changer le texte de Que Faisons-Nous ?</label>
                <textarea name="QFN" class="form-control" rows="5"><?php echo $QFN; ?></textarea>
            </div>
 
            <div class="mb-3">
                <label for="image1" class="form-label">Voulez-vous changer l'image de Qui Sommes-Nous ? (actuelle)</label>
                <input type="text" class="form-control" id="image1" name="image1" value="<?php echo $image1; ?>" readonly>
                <input type="file" class="form-control mt-2" name="image11">
            </div>
 
            <div class="mb-3">
                <label for="image2" class="form-label">Voulez-vous changer l'image de Que Faisons-Nous ? (actuelle)</label>
                <input type="text" class="form-control" id="image2" name="image2" value="<?php echo $image2; ?>" readonly>
                <input type="file" class="form-control mt-2" name="image22">
            </div>
 
            <input type="hidden" name="identifiant" value="<?php echo $identifiant; ?>">
 
            <!-- Bouton de mise à jour -->
            <button type="submit" name="update" class="form-control button mt-4 red">Mettre à jour</button>
        </form>
 
        <!-- Affichage d'un message d'erreur si nécessaire -->
        <?php if(!empty($error_message)) { ?>
            <div class="alert alert-danger mt-3"><?php echo $error_message; ?></div>
        <?php } ?>
    </div>
</div>
 
</body>
</HTML>