<!--accueil.php-->
<!DOCTYPE HTML>

<HTML>
<HEAD>
	<meta charset = "UTF-8">
	<meta name = "viewport" content = "width = device-width, initial-scale = 1.0">

	<!--CSS de Bootstrap-->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <!--JAVASCRIPT de Bootstrap-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

	<link href = "c_style_accueil.css" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">

    <title> Accueil </title>
</HEAD>


<BODY>

	<!--DEBUT NAVBAR-->
    <nav class="navbar navbar-expand-lg fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand me-auto">
            <img src="images/logo_supercar.png" alt="logo" width="50" class="d-inline-block align-text-middle">
            Supercar
        </a>
        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
            <div class="offcanvas-header">
                <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menu</h5>
                <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            
            <div class="offcanvas-body">
                <ul class="navbar-nav justify-content-center flex-grow-1 pe-3">
                    <li class="nav-item">
                        <a class="nav-link mx-lg-2 active" aria-current="page" href="c_accueil.php">Accueil</a>
                    </li>
                    
                    <?php
                    include("connexion.php");
                        $query = "SELECT distinct marque FROM VOITURE";
                        $result = mysqli_query($bdd, $query);
                            if (!$result) {
                                die("Query failed: " . mysqli_error($bdd));
                                }
                    ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link mx-lg-2 dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Voitures</a>
                                <ul class="dropdown-menu">
                                
                                <?php
                                    while ($row = mysqli_fetch_assoc($result)) {
                                    $marque = $row['marque'];
                                    $lien_voiture = "c_voiture_marque.php?marque=" . strtolower($marque);
                                ?>
                                    <li><a class="dropdown-item" href="<?php echo $lien_voiture; ?>"><?php echo $marque; ?></a></li>
                                    <?php
                                        }
                                    ?>
                                </ul>
                    </li>

                    <?php

                        mysqli_close($bdd);
                    ?>


                   <li class="nav-item">
                        <a class="nav-link mx-lg-2" href="c_services.php">Services</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link mx-lg-2" href="c_demande.php">Demande d'essai</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link mx-lg-2" href="c_contact.php">Contact</a>
                    </li>
                    
                    
                </ul>
            </div>
        </div>
        
        <a href="c_inscription.php" class="login-button"> Inscription </a>
        <button class="navbar-toggler pe-0" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
    </nav>
    <!--FIN NAVBAR-->

	<!--DEBUT HERO SECTION-->
	<section class="hero-section" style="background: url(images/cars.jpg) no-repeat center; ; background-size: cover;">
        <div class="container d-flex align-items-center justify-content-center fs-1 text-white flex column">
            <h2>Est. 2009</h2>
        </div>
    </section>

	<!--FIN HERO SECTION-->

	<?php
        include("connexion.php");
        $selection = "SELECT * FROM p_accueil WHERE Identifiant = '1'";
        $curseur = mysqli_query($bdd, $selection);


        if ($curseur) {
    // Assurez-vous qu'il y a des résultats à afficher
            if (mysqli_num_rows($curseur) > 0) {
                while ($row = mysqli_fetch_array($curseur)) {
                    $QSN = $row["QSN"];
                    $QFN = $row["QFN"];
                    $image1 = $row["image1"];
                    $image2 = $row["image2"];

                    echo "<div class='container-fluid mt-3 mx-auto'>";
                    echo "<div class='row'>";

                    echo "<div class='col-sm-4'><img src='$image1' alt='kia' width='100%'></div>";
                    echo "<div class='col-sm-4 p-3 milieu'>";
                    echo "<div class='container-fluid'>
                        <h5> Qui sommes-nous </h5>
                        <p> $QSN </p>
                    </div>
                  </div>";

            echo "<div class='col-sm-2'></div>";
            echo "</div>";

            echo "<div class='row mt-4'>";
            echo "<div class='col-sm-2'></div>";

            echo "<div class='col-sm-4 p-3 milieu'>";
            echo "<div class='container-fluid'>
                        <h5> Que faisons-nous?</h5>
                        <p> $QFN </p>
                    </div> 
                </div>";

            echo "<div class='col-sm-4'><img src='$image2' width='100%'></div>";
            echo "</div>"; // Correction de la balise d'ouverture
            echo "</div>";
            echo "</div>";
        }

        // Libérer la mémoire du serveur de la variable $curseur
        mysqli_free_result($curseur);
            } else {
        // Gérer le cas où la requête ne renvoie pas de résultats
                echo "Aucun résultat trouvé.";
                }
        } else {
    // Gérer l'erreur si la requête échoue
    echo "Erreur de requête : " . mysqli_error($bdd);
        }
        ?>
				
		  	
	<!--FIN CONTENU DE LA PAGE-->

	<!--DEBUT DU FOOTER-->
	<footer class="bg-dark mt-5 bottom">
    <div class="container p-4 text-light">
        <small class="text-white-50"> Supercar </small>
        <small class="text-white-50">&copy; Copyright by Supercar </small>
        <div class="container-fluid mt-3">
            <div class="container-fluid mt-3">
                <div class="row footer justify-content-center">
                    <div class="col p-4 text-white text-center"><a href = "#"> Mentions Légales</a></div>
                    <div class="col p-4 text-white text-center"><a href = "#">Politique de confidentialité</a></div>
                    <div class="col p-4 text-white text-center"><a href = "#">Contact</a></div>
                </div>
            </div>
        </div>
    </div>
</footer>


</BODY>

</HTML>	