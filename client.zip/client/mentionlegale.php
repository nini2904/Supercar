<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mentions Légales</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include 'navbar.php'; ?>
    <div class="container bg-dark text-white py-3"style="margin-top:5%;">
        <h1 class="text-center" >Mentions Légales</h1>
    </div>


    <main class="container mt-4">
        <section class="mb-4">
            <h2 class="h4">1. Identification de l'Éditeur du Site</h2>
            <ul>
                <li><strong>Nom ou raison sociale :</strong> SuperCar</li>
                <li><strong>Adresse postale :</strong> Siège social, Ebene, Île Maurice</li>
            </ul>
        </section>

        <section class="mb-4">
            <h2 class="h4">2. Hébergeur du Site</h2>
            <ul>
                <li><strong>Nom de l'hébergeur :</strong> MultiSys</li>
                <li><strong>Adresse :</strong>Ebene, Île Maurice</li>
                <li><strong>Contact :</strong> <a href="contact.php">Contact</a> </li>
            </ul>
        </section>

        <section class="mb-4">
            <h2 class="h4">3. Propriété Intellectuelle</h2>
            <p>Tous les contenus présents sur ce site (textes, images, logos, vidéos) sont protégés par les lois en vigueur sur la propriété intellectuelle. Toute reproduction ou utilisation sans autorisation est strictement interdite.</p>
        </section>

        <section class="mb-4">
            <h2 class="h4">4. Données Personnelles</h2>
            <p>Les informations collectées via ce site (formulaires, cookies) sont utilisées conformément à notre <a href="politiqueconf.php">Politique de Confidentialité</a>. Conformément au RGPD, vous disposez d’un droit d’accès, de rectification et de suppression de vos données.</p>
        </section>

        <section class="mb-4">
            <h2 class="h4">5. Responsabilité</h2>
            <p>L’éditeur ne peut être tenu responsable des erreurs ou des omissions présentes sur ce site, ni des éventuels dommages liés à son utilisation. Les liens externes proposés sur ce site sont fournis à titre informatif et leur contenu reste sous la responsabilité de leurs éditeurs respectifs.</p>
        </section>

        <section class="mb-4">
            <h2 class="h4">6. Cookies</h2>
            <p>Ce site utilise des cookies pour améliorer l'expérience utilisateur et pour des analyses statistiques. Vous pouvez gérer vos préférences via votre navigateur ou consulter notre <a href="politiqueconf.php">Politique de Confidentialité</a> pour plus d'informations.</p>
        </section>
    </main>

    <?php include 'footer.php'; ?>  

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
