<!DOCTYPE HTML>
<HTML>
<HEAD>
<meta charset = "UTF-8">
<meta name = "viewport" content = "width = device-width, initial-scale = 1.0">
<title> Visualiser Acceuil </title>
 
    <!--CSS de Bootstrap-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
 
    <!--JAVASCRIPT de Bootstrap-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
 
    <link href = "a_style_menu.css" rel="stylesheet">
</HEAD>
<BODY>
 
 
    <!---------- Partie PHP ---------->
 
<?php

include("connexion.php");
$result = mysqli_query($bdd, "SELECT * FROM p_accueil ORDER BY identifiant DESC");
?>

 
<!---------- Fin du PHP ------------>
 
    
<div class="container one p-5">
<a href="a_menu_accueil.html">Retour</a>

    <table>
      <thead>
        <tr>
          <th >Identifiant</th>
          <th >Qui Sommes-Nous</th>
          <th >Que Faisons-Nous</th>
          <th >Image1</th>
          <th >Image2</th>
        </tr>
      </thead>

<?php 
// Requête pour récupérer les données après la suppression
$result = mysqli_query($bdd, "SELECT * FROM p_accueil");

while ($res = mysqli_fetch_array($result)) {         
    echo "<tr>";
    echo "<td>".$res['identifiant']."</td>";
    echo "<td>".$res['QSN']."</td>";
    echo "<td>".$res['QFN']."</td>"; 
    echo "<td>".$res['image1']."</td>";
    echo "<td>".$res['image2']."</td>";


    echo "</tr>";
}
?>
</table>
</div>     

 
</BODY>
</HTML>