<!DOCTYPE HTML>
<HTML lang="fr">
<HEAD>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--CSS de Bootstrap-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <!--JAVASCRIPT de Bootstrap-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <title>Inscription</title>
    <style>
        :root {
            --primary-color: #C1121F;
            --primary-hover: #780000;
            --text-color: #ffffff;
        }
        
        body {
            background-image: url("images/inscription.jpg");
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-position: center;
            color: var(--text-color);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        .form-container {

            padding: 30px;
            margin-top: 3rem;
            margin-bottom: 2rem;

        }
        
        .form-control {
            background-color: rgba(255, 255, 255, 0) !important;
            color: var(--text-color) !important;
            border: none;
            border-bottom: 2px solid var(--text-color);
            border-radius: 0;
            padding: 12px 20px;
            margin: 8px 0;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            background-color: rgba(255, 255, 255, 0.2) !important;
            box-shadow: none;
            border-color: var(--primary-color);
        }
        
        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }
        
        .btn-rouge {
            background-color: var(--primary-color) !important;
            color: var(--text-color) !important;
            border-radius :20px;
        }
        
        .btn-rouge:hover {
            background-color: var(--primary-hover) !important;

            border-radius :20px;
        }

        .status-message {
            margin-top: 15px;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
        }
        
        .success {
            background-color: rgba(2, 23, 61, 0.7);
        }
        
        .error {
            background-color: rgba(220, 53, 69, 0.7);
        }
        
</style>
</HEAD>

<BODY>

<?php include 'navbar.php'; ?>

<?php
// Include the database connection
include("connexion.php");

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data and sanitize input
    $nom = htmlspecialchars($_POST["nom"]);
    $prenom = htmlspecialchars($_POST["prenom"]);
    $email = htmlspecialchars($_POST["email"]);
    $numero = htmlspecialchars($_POST["numero"]);
    $username = htmlspecialchars($_POST["username"]);
    $password = $_POST["mdp"];
    $confirmpasswrd = $_POST["confirmpasswrd"];

    // Check if passwords match
    if ($password === $confirmpasswrd) {
        // Hash the password (you should use a stronger hashing algorithm in a real-world scenario)
        $hashedPassword = md5($password);

        // Prepare your SQL query to insert data into the "INSCRIPTION" table
        $insertQuery = "INSERT INTO INSCRIPTION (nom, prenom, email, numero, username, password) VALUES ('$nom', '$prenom', '$email', '$numero', '$username', '$hashedPassword')";

        // Execute the query using mysqli_query
        if (mysqli_query($bdd, $insertQuery)) {
            $status = "Enregistrement réussi!";
            $statusClass = "success";
        } else {
            $status = "Error: " . mysqli_error($bdd);
            $statusClass = "error";
        }
    } else {
        // Passwords do not match
        $status = "Les mots de passe ne correspondent pas.";
        $statusClass = "error";
    }
}

// Close the database connection
mysqli_close($bdd);
?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-8 col-md-10 col-12">
            <div class="form-container">
                <h2 class="text-center fw-bold mb-4">Inscrivez-vous</h2>
                
                <form class="form-group" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <div class="row">
                        <div class="col-md-6 col-12">
                            <div class="mb-3">
                                <label for="nom" class="form-label">Nom</label>
                                <input type="text" class="form-control" id="nom" name="nom" required>
                            </div>
                        </div>
                        <div class="col-md-6 col-12">
                            <div class="mb-3">
                                <label for="prenom" class="form-label">Prénom</label>
                                <input type="text" class="form-control" id="prenom" name="prenom" required>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 col-12">
                            <div class="mb-3">
                                <label for="numero" class="form-label">Numéro de téléphone</label>
                                <input type="tel" class="form-control" id="numero" name="numero" required>
                            </div>
                        </div>
                        <div class="col-md-6 col-12">
                            <div class="mb-3">
                                <label for="email" class="form-label">Adresse mail</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="username" class="form-label">Nom d'utilisateur</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>

                    <div class="mb-3">
                        <label for="mdp" class="form-label">Mot de passe</label>
                        <input type="password" class="form-control" id="mdp" name="mdp" required>
                    </div>

                    <div class="mb-3">
                        <label for="confirmpasswrd" class="form-label">Confirmer le mot de passe</label>
                        <input type="password" class="form-control" id="confirmpasswrd" name="confirmpasswrd" required>
                    </div>

                    <?php if (isset($status)): ?>
                    <div class="status-message <?php echo $statusClass; ?>">
                        <?php echo $status; ?>
                    </div>
                    <?php endif; ?>

                    <div class="row mt-4">
                        <div class="col-md-6 col-12 mb-3">
                            <button type="submit" class="btn btn-rouge w-100">S'enregistrer</button>
                        </div>
                        <div class="col-md-6 col-12 mb-3">
                            <button type="reset" class="btn btn-rouge w-100">Annuler</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>

</BODY>
</HTML>