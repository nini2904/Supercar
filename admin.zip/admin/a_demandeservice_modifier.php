<!DOCTYPE HTML>
<HTML>
<HEAD>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title> Demande de services </title>

    <!-- CSS de Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <!-- JAVASCRIPT de Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <link href="a_style_menu.css" rel="stylesheet">
</HEAD>
<BODY>

<div class="container one p-5">
<a href="a_menu_demande_service.html">Retour</a>
<?php
include("connexion.php");

$error_message = "";

if(isset($_GET['id_service']) && isset($_GET['statut_service'])) {
    $id_service = htmlspecialchars($_GET['id_service']);
    $new_status = htmlspecialchars($_GET['statut_service']);  // Nouveau statut choisi

    // Vérifier si le statut est valide avant de mettre à jour
    if (in_array($new_status, ['En attente', 'Confirmé', 'Terminé', 'Annulé'])) {
        // Mettre à jour le statut de la demande d'essai
        $stmt = mysqli_prepare($bdd, "UPDATE service  SET statut_service=? WHERE id_service=?");
        mysqli_stmt_bind_param($stmt, "si", $new_status, $id_service);

        if (mysqli_stmt_execute($stmt)) {
            header("Location: a_demandeservice_modifier.php"); // Rediriger après mise à jour
            exit();
        } else {
            $error_message = "Échec de la mise à jour du statut.";
        }
        mysqli_stmt_close($stmt);
    } else {
        $error_message = "Statut invalide.";
    }
}
?>

<?php
// Requête pour récupérer toutes les demandes d'essai
$result = mysqli_query($bdd, "SELECT id_service, date_service, statut_service FROM service ORDER BY id_service DESC");
?>

<!-- Table pour afficher les demandes d'essai -->
<table>
    <thead>
        <tr>
            <th>Identifiant</th>
            <th>Date de la demande</th>
            <th>Heure</th>
            <th>Statut</th>
            <th colspan="4">Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php 
    while ($res = mysqli_fetch_array($result)) {         
        echo "<tr>";
        echo "<td>".$res['id_service']."</td>";
        echo "<td>".$res['date_service']."</td>";
        echo "<td>".$res['statut_service']."</td>"; 

        // Liens pour modifier le statut
        echo "<td><a href=\"a_demandeservice_modifier.php?id_service=" . urlencode($res['id_service']) . "&statut_service=En attente\">En attente</a></td>";
        echo "<td><a href=\"a_demandeservice_modifier.php?id_service=" . urlencode($res['id_service']) . "&statut_service=Confirmé\">Confirmé</a></td>";
        echo "<td><a href=\"a_demandeservice_modifier.php?id_service=" . urlencode($res['id_service']) . "&statut_service=Terminé\">Terminer</a></td>";
        echo "<td><a href=\"a_demandeservice_modifier.php?id_service=" . urlencode($res['id_service']) . "&statut_service=Annulé\">Annuler</a></td>";
        

        // Ajouter le lien pour supprimer si nécessaire
    
        echo "</tr>";
    }
    ?>
    </tbody>
</table>

<?php
if ($error_message) {
    echo "<div class='alert alert-danger'>$error_message</div>";
}
?>

</div>
</BODY>
</HTML>
