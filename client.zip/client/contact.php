<!DOCTYPE HTML>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- CSS de Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <link href="c_style_forms.css" rel="stylesheet">

    <title>Contactez-nous</title>
    <style>
    body {
        background-image: url("images/cars.jpg");
        background-size: cover; /* Ajuste l'image pour couvrir toute la surface */
        background-repeat: no-repeat; /* Empêche la répétition de l'image */
        background-attachment: fixed; /* L'image reste fixe lors du défilement */
        background-position: center; /* Centre l'image */
        color: white;
        margin: 0;
        background-color: black;
    }


    @media (max-width: 768px) {
        body {
            background-size: contain; /* Ajuste l'image pour s'adapter à la taille de l'écran */
            background-position: top; /* Permet un meilleur alignement pour les petits écrans */
        }
    }


    input[type="text"],
    input[type="email"],
    input[type="tel"],
    textarea {
        width: 100%;
        padding: 12px;
        margin: 8px 0;
        box-sizing: border-box;
        border: none;
        border-bottom: 2px solid white;
        background: rgba(255, 255, 255, 0.61);
    }

    .form-control {
        background-color: transparent !important;
        color: white !important;
    }

    .btn {
        background-color: rgb(146, 12, 12);
        color: white;
        border: none;
        padding: 10px 20px;
        cursor: pointer;
        font-size: 16px;
        width: 100%;
    }

    .btn:hover {
        background-color: rgb(219, 19, 19);
    }

    @media (max-width: 768px) {
        body {
            background-size: cover;
        }

    .bg {
        padding: 20px;
        }
    }
    html, body {
        height: 100%;
        display: flex;
        flex-direction: column;
        margin: 0;
    }

    main {
        flex: 1;
    }
    .container-fluid{
        margin-top : 6%;
    }

    </style>
</head>

<body>
<?php include 'navbar.php'; ?>
<main>
    <div class="container-fluid mt-5">
        <div class="row">
            <!-- Formulaire -->
            <div class="col-md-6 mb-4">
                <form class="form-group" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <div class="bg p-4 rounded">
                        <h2 class="text-center fw-bold">Contactez-nous</h2>

                        <div class="row">
                            <div class="col-md-6">
                                <label for="nom" class="form-label mt-3">Nom</label>
                                <input type="text" class="form-control" name="nom" required>
                            </div>
                            <div class="col-md-6">
                                <label for="prenom" class="form-label mt-3">Prénom</label>
                                <input type="text" class="form-control" name="prenom" required>
                            </div>
                        </div>

                        <label for="numero" class="form-label mt-2">Numéro de téléphone</label>
                        <input type="tel" class="form-control" name="numero" required>

                        <label for="email" class="form-label mt-2">Email</label>
                        <input type="email" class="form-control" name="email" required>

                        <label for="message" class="form-label mt-2">Votre message</label>
                        <textarea name="message" class="form-control" rows="3" required></textarea>

                        <div class="row mt-3">
                            <div class="col-md-6 mb-2">
                                <button type="submit" class="btn">Envoyer</button>
                            </div>
                            <div class="col-md-6 mb-2">
                                <button type="reset" class="btn">Annuler</button>
                            </div>
                        </div>

                        <div id="status" class="text-center mt-3">
                            <?php if (isset($status)) echo $status; ?>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Google Maps -->
            <div class="col-md-6 mb-4" style="margin-top:7%">


                <div class="ratio ratio-16x9">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3743.300603100819!2d57.4867236750589!3d-20.246364181214318!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x217c5b1ef2170f63%3A0xd1a78020fc096491!2sMCCI%20BUSINESS%20SCHOOL%20(Mauritius%20Chamber%20of%20Commerce%20and%20Industry)!5e0!3m2!1sfr!2smu!4v1742648645117!5m2!1sfr!2smu"
                        style="border:0; width: 100%; height: 100%;" loading="lazy"
                        referrerpolicy="no-referrer-when-downgrade">
                    </iframe>
                </div>
            </div>
        </div>
    </div>
</main>
    <!--Footer-->
    <?php include 'footer.php'; ?>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>


</html>
