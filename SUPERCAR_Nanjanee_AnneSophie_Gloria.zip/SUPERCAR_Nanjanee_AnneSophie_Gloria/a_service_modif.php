<!DOCTYPE HTML>
<HTML>
<HEAD>
<meta charset = "UTF-8">
<meta name = "viewport" content = "width = device-width, initial-scale = 1.0">
<title> Modification Service </title>
 
    <!--CSS de Bootstrap-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
 
    <!--JAVASCRIPT de Bootstrap-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
 
    <link href = "a_style_menu.css" rel="stylesheet">
</HEAD>
<BODY>



<?php
include("connexion.php");

$error_message = "";

if(isset($_POST['update'])) {
    $identifiant = htmlspecialchars($_POST['identifiant']);
    $image = htmlspecialchars($_POST['image']);
    $type = htmlspecialchars($_POST['type_service']);
    $description = htmlspecialchars($_POST['description_service']);
    $image2 = htmlspecialchars($_POST['image2']);
    $image3 = 'images/' . $image2;

    if(empty($image) || empty($type) || empty($description)) {            
        $error_message = "All fields are required.";
    } else {    
        $stmt = mysqli_prepare($bdd, "UPDATE p_service SET image=?, type_service=?, description_service=? WHERE identifiant=?");
        mysqli_stmt_bind_param($stmt, "sssi", $image3, $type, $description, $identifiant);
        
        if(mysqli_stmt_execute($stmt)) {
            header("Location: a_service_modifier.php");
            exit();
        } else {
            $error_message = "Failed to update service.";
        }
        mysqli_stmt_close($stmt);
    }
}

$identifiant = htmlspecialchars($_GET['identifiant']);
$result = mysqli_query($bdd, "SELECT * FROM p_service WHERE identifiant=$identifiant");

if(mysqli_num_rows($result) == 0) {
    // Handle case where service does not exist
}

$res = mysqli_fetch_array($result);
$image = $res['image'];
$type = $res['type_service'];
$description = $res['description_service'];

?>



    <?php if(!empty($error_message)) { ?>
        <p style="color: red;"><?php echo $error_message; ?></p>
    <?php } ?>

  <div class="container one p-5">
  <a href="a_menu_service.html">Retour</a>
    <div class="mb-3 p-5">
        <h4 class="text-center fw-bold">Modification</h4>
        <form class="form-group" method="post" action="a_service_modif.php">
            <label for="image" class="form-label mt-3">Image</label>
            <input type="text" class="form-control" id="image" name="image" value="<?php echo $image;?>" required>

            <div class="mb-3">
                    <label for="inputGroupFile02" class="form-label">Télécharger l'image</label>
                    <input type="file" class="form-control" name="image2" required>
                </div>
       
       <label for="type_service" class="form-label mt-3">Type</label>
            <input type="text" class="form-control" id="type_service" name="type_service" value="<?php echo $type;?>" required>
            
            <label for="description_service" class="form-label mt-3">Description</label>
            <textarea class="form-control" id="description_service" name="description_service" rows="4" required><?php echo $description;?></textarea>
        
            <input type="hidden" name="identifiant" value="<?php echo $identifiant; ?>">
        
                <button type="submit" name="update" class="form-control button mt-4 red">Update</button>
            
    </form>
</div>
</div>
</BODY>
</HTML>



