<?php
session_name("supercar_session"); // Pour Supercar
session_start();
include("connexion.php"); // Connexion à la base de données

// Gestion de la connexion
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['username'], $_POST['mdp'])) {
    $username = mysqli_real_escape_string($bdd, $_POST["username"]);
    $password = md5(mysqli_real_escape_string($bdd, $_POST["mdp"])); // Hachage du mot de passe avec MD5

    // Requête pour récupérer les informations utilisateur
    $query = "SELECT id_inscription, nom, prenom, email, password FROM INSCRIPTION WHERE username='$username'";
    $curseur = mysqli_query($bdd, $query);
    
    if ($curseur) {
        $row = mysqli_fetch_assoc($curseur);

        // Vérification si l'utilisateur existe
        if ($row) {
            if ($row['password'] === $password) {  
                $_SESSION['id_inscription'] = $row['id_inscription'];
                $_SESSION['nom'] = $row['nom'];
                $_SESSION['prenom'] = $row['prenom'];
                $_SESSION['email'] = $row['email'];

                // Créer un cookie pour garder l'utilisateur connecté
                $token = bin2hex(random_bytes(16));
                setcookie('login_token', $token, time() + 3600, "/", "", false, true);

                $userId = $row['id_inscription'];
                $query = "UPDATE INSCRIPTION SET session_token='$token' WHERE id_inscription='$userId'";
                mysqli_query($bdd, $query);

                // Redirection après la connexion
                header("Location: index.php");
                exit();
            } else {
                $status = "Le mot de passe est incorrect.";
                $statusClass = "error";
            }
        } else {
            $status = "Nom d'utilisateur ou mot de passe incorrect.";
            $statusClass = "error";
        }

        mysqli_free_result($curseur);
    } else {
        $status = "Erreur lors de l'exécution de la requête.";
        $statusClass = "error";
    }

    mysqli_close($bdd);
}
?>

<!DOCTYPE HTML>
<HTML lang="fr">
<HEAD>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- CSS de Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <!-- JavaScript de Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <title>Connexion</title>
    <style>
        :root {
            --primary-color: #C1121F;
            --primary-hover: #780000;
            --text-color: #ffffff;
        }
        
        body {
            background-image: url("images/login.jpg");
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-position: center;
            color: var(--text-color);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        .login-container {
            display: flex;
            align-items: center;
            justify-content: center;
            flex: 1;
            padding: 2rem 0;
        }
        
        .form-container {
            background-color: rgba(255, 255, 255, 0.17);

            padding: 30px;

            width: 100%;
            max-width: 700px;
        }
        
        .form-control {
            background-color: rgba(255, 255, 255, 0.1) !important;
            color: var(--text-color) !important;
            border: none;
            border-bottom: 2px solid var(--text-color);
            border-radius: 0;
            padding: 12px 20px;
            margin: 8px 0;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            background-color: rgba(255, 255, 255, 0.2) !important;
            box-shadow: none;
            border-color: var(--primary-color);
        }
        
        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }
        
        .btn{
    background-color: #C1121F ;
    border:none;
    color: #fff;
    border-radius :20px;

}
.btn:hover {
    background-color: #780000;
    color: #fff;
    border-radius :20px;
}
        
        .status-message {
            margin-top: 15px;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
        }
        
        .success {
            background-color: rgba(2, 23, 61, 0.7);
        }
        
        .error {
            background-color: rgba(220, 53, 69, 0.7);
        }
        

    </style>
</HEAD>

<BODY>

<?php include 'navbar.php'; ?>

<div class="login-container">
    <div class="form-container">
        <h2 class="text-center fw-bold mb-4">Connectez-vous</h2>
        
        <form class="form-group" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="mb-3">
                <label for="username" class="form-label">Nom d'utilisateur</label>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>

            <div class="mb-3">
                <label for="mdp" class="form-label">Mot de passe</label>
                <input type="password" class="form-control" id="mdp" name="mdp" required>
            </div>

            <?php if (isset($status)): ?>
            <div class="status-message <?php echo $statusClass; ?>">
                <?php echo $status; ?>
            </div>
            <?php endif; ?>

            <div class="row mt-4">
                <div class="col-md-6 col-12 mb-3">
                    <button type="submit" class="btn w-100">Se connecter</button>
                </div>
                <div class="col-md-6 col-12 mb-3">
                    <button type="reset" class="btn w-100">Annuler</button>
                </div>
            </div>
            
            <div class="text-center mt-3">
                <p>Pas encore de compte ? <a href="inscription.php" class="text-info">Inscrivez-vous ici</a></p>
            </div>
        </form>
    </div>
</div>

<?php include 'footer.php'; ?>

</BODY>
</HTML>