<?php 
include("connexion.php");
$id_voiture = $_GET['id_voiture'];
$result = mysqli_query($bdd, "DELETE FROM voiture WHERE id_voiture=$id_voiture");
header("Location:a_voiture_supprimer.php");
?>