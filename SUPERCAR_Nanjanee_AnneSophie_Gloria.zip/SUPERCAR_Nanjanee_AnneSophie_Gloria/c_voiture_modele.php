<!DOCTYPE HTML>

<HTML>
<HEAD>
    <meta charset = "UTF-8">
    <meta name = "viewport" content = "width = device-width, initial-scale = 1.0">

    <!--CSS de Bootstrap-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <!--JAVASCRIPT de Bootstrap-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <link href = "c_style_accueil.css" rel="stylesheet">
    <title> Voitures </title>


</HEAD>

<BODY>

    <!--DEBUT NAVBAR-->
    <nav class="navbar navbar-expand-lg fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand me-auto">
            <img src="images/logo_supercar.png" alt="logo" width="50" class="d-inline-block align-text-middle">
            Supercar
        </a>
        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
            <div class="offcanvas-header">
                <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menu</h5>
                <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            
            <div class="offcanvas-body">
                <ul class="navbar-nav justify-content-center flex-grow-1 pe-3">
                    <li class="nav-item">
                        <a class="nav-link mx-lg-2" aria-current="page" href="c_accueil.php">Accueil</a>
                    </li>
                    

                    <?php

                    include("connexion.php");

                        $query = "SELECT distinct marque FROM VOITURE";
                        $result = mysqli_query($bdd, $query);


                            if (!$result) {
                                die("Query failed: " . mysqli_error($bdd));
                                }
                    ?>

                    <li class="nav-item dropdown">
                        <a class="nav-link mx-lg-2 dropdown-toggle active" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Voitures</a>
                                <ul class="dropdown-menu">
                                    <?php
          
                                    while ($row = mysqli_fetch_assoc($result)) {
                                    $marque = $row['marque'];
                                    $lien_voiture = "c_voiture_marque.php?marque=" . strtolower($marque);
                                    ?>
                                    <li><a class="dropdown-item" href="<?php echo $lien_voiture; ?>"><?php echo $marque; ?></a></li>
                                    <?php
                                        }
                                    ?>
                                </ul>
                    </li>

                    <?php

                        mysqli_close($bdd);
                    ?>


                   <li class="nav-item">
                        <a class="nav-link mx-lg-2" href="c_services">Services</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link mx-lg-2" href="c_demande.php">Demande d'essai</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link mx-lg-2" href="c_contact.php">Contact</a>
                    </li>
                    
                    
                </ul>
            </div>
        </div>
        
        <a href="c_inscription.php" class="login-button"> Inscription </a>
        <button class="navbar-toggler pe-0" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
    </nav>
    <!--FIN NAVBAR-->


    <?php
include("connexion.php");

// Your original code used $marque, but here it should be $modele for consistency
$modele = isset($_GET['modele']) ? $_GET['modele'] : '';

// Validation or sanitization could be added here

// Initialize the flag for the hero section
$heroSectionDisplayed = false;

// Prepare your SQL query to select data from the "voiture" table with the condition on the "modele"
$selection = "SELECT * FROM voiture WHERE modele = '$modele'";

// Execute the query to retrieve data into the $curseur variable
$curseur = mysqli_query($bdd, $selection);

// Make sure the query executed successfully

if ($curseur) {
    while ($row = mysqli_fetch_array($curseur)) {
        // BEGIN HERO SECTION
        if (!$heroSectionDisplayed) {
            $logo_marque = $row["logo_marque"];
            $row_marque = $row["marque"];

            echo "<section class='hero-section' style='background: url($logo_marque) center/cover no-repeat;'>";
            echo "<div class='container d-flex align-items-center justify-content-center fs-1 text-white flex column'>";
            echo "<h1>" . strtoupper($row_marque) . "</h1>"; // Use $row_marque instead of $marque
            echo "</div>";
            echo "</section>";

            $heroSectionDisplayed = true; // Set to true after displaying the hero section
        }
        // END HERO SECTION

        // BEGIN CAR DETAILS
        $modele = $row["modele"];
        $annee = $row["annee"];
        $description_interieur = $row["description_interieur"];
        $description_exterieur = $row["description_exterieur"];
        $image_front = $row["image_front"];
        $image_back = $row["image_back"];
        $image_interieur = $row["image_interieur"];
        $image_profile = $row["image_profile"];
        $prix = $row["prix"];
        $logo_prix = $row["logo_prix"];
        $logo_vitesse = $row["logo_vitesse"];
        $vitesse = $row["vitesse"];

       echo "<div class='container-fluid mt-3 mx-auto'>";



echo "<table class='table car-details'>";
echo "<tr>";
echo "<td><img src='$image_front' width='100%' alt='Front View'></td>";
echo "<td>";
echo "<h1><b><center>$modele<center></b></h1>";
echo "<p><center><b>Année:</b> $annee</center></p>";
echo "</td>";
echo "</tr>";

echo "<tr>";
echo "<td>";
echo "<p><img src='$logo_prix' alt='logo Prix' width='60'>$prix</p>";
echo "<p><img src='$logo_vitesse' alt='logo vitesse' width='55'>$vitesse</p>";
echo "</td>";
echo "<td>";
echo "<img src='$image_back' width='100%' alt='Back View'></td>";
echo "</tr>";

echo "<tr>";
echo "<td>";
echo "<img src='$image_profile' width='100%' alt='Back View'></td>";
echo "<td>";
echo "<p><h3><b><center>Extérieure</center></h3></b></p>";
echo "<p><center>$description_exterieur</center></p>";
echo "</td>";
echo "<tr>";



echo "<tr>";
echo "<td>";
echo "<h3><b><center>Intérieure</center></b></h3>";
echo "<p> <center>$description_interieur</center></p>";
echo "</td>";
echo "<td><img src='$image_interieur' width='100%' alt='Interior View'></td>";
echo "</tr>";

echo "</table>";
echo "</div>";

    }

    // Free up the server's memory for the $curseur variable
    mysqli_free_result($curseur);
} else {
    // Handle the error if the query fails
    echo "Erreur de requête : " . mysqli_error($bdd);
}

// Close the connection with the database
mysqli_close($bdd);
?>
</BODY></HTML>





    