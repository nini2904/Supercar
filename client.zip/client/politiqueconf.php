<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Politique de Confidentialité</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include 'navbar.php'; ?>
    <div class="container bg-dark text-white py-3"style="margin-top:5%;">
            <h1 class="text-center">Politique de Confidentialité</h1>
    </div>
    <main class="container my-5">
        <section class="mb-4">
            <h2 class="h4">1. Introduction</h2>
            <p>Bienvenue sur le site Supercar. Votre confidentialité est importante pour nous. Cette politique explique quelles données personnelles nous collectons et comment nous les utilisons.</p>
        </section>
        <section class="mb-4">
            <h2 class="h4">2. Données collectées</h2>
            <ul>
                <li><strong>Données fournies par l'utilisateur :</strong> Nom, e-mail, téléphone, etc.</li>
                <li><strong>Données techniques :</strong> Adresse IP, type de navigateur, pages visitées.</li>
                <li><strong>Cookies :</strong> Fonctionnels et analytiques.</li>
            </ul>
        </section>
        <section class="mb-4">
            <h2 class="h4">3. Finalité de la collecte</h2>
            <p>Nous utilisons vos données pour :</p>
            <ul>
                <li>Répondre à vos demandes via nos formulaires.</li>
                <li>Améliorer nos services et personnaliser votre expérience.</li>
                <li>Vous envoyer des offres, si vous y avez consenti.</li>
            </ul>
        </section>
        <section class="mb-4">
            <h2 class="h4">4. Partage des données</h2>
            <p>Vos données peuvent être partagées avec nos partenaires ou les autorités, si nécessaire. Nous ne vendons jamais vos données personnelles.</p>
        </section>
        <section class="mb-4">
            <h2 class="h4">5. Vos droits</h2>
            <p>Conformément à la RGPD, vous disposez des droits suivants :</p>
            <ul>
                <li>Droit d'accès, de rectification et d'effacement.</li>
                <li>Droit d'opposition et de limitation.</li>
                <li>Droit à la portabilité.</li>
            </ul>
        </section>
        <section class="mb-4">
            <h2 class="h4">6. Sécurité des données</h2>
            <p>Nous protégeons vos données avec des mesures techniques et organisationnelles adaptées.</p>
        </section>
        <section class="mb-4">
            <h2 class="h4">7. Modifications</h2>
            <p>Cette politique peut être modifiée. Toute modification sera publiée sur cette page.</p>
        </section>
    </main>

    <!-- Bootstrap JS -->
<?php include 'footer.php'; ?>  
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
